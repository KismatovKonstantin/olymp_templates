latex file.tex
latex file.tex
dvipdfm file.dvi
rm *.aux *.log *.dvi
